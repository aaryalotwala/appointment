/* Generated file, do not edit */

#ifndef CXXTEST_RUNNING
#define CXXTEST_RUNNING
#endif

#define _CXXTEST_HAVE_STD
#include <cxxtest/TestListener.h>
#include <cxxtest/TestTracker.h>
#include <cxxtest/TestRunner.h>
#include <cxxtest/RealDescriptions.h>
#include <cxxtest/TestMain.h>
#include <cxxtest/ErrorPrinter.h>

int main( int argc, char *argv[] ) {
 int status;
    CxxTest::ErrorPrinter tmp;
    CxxTest::RealWorldDescription::_worldName = "cxxtest";
    status = CxxTest::Main< CxxTest::ErrorPrinter >( tmp, argc, argv );
    return status;
}
bool suite_Test_init = false;
#include "../newCxxTest.h"

static Test suite_Test;

static CxxTest::List Tests_Test = { 0, 0 };
CxxTest::StaticSuiteDescription suiteDescription_Test( "/Users/jineshpatel/Desktop/CSC109/Projects/Ch-10Appointment/newCxxTest.h", 19, "Test", suite_Test, Tests_Test );

static class TestDescription_suite_Test_testTime : public CxxTest::RealTestDescription {
public:
 TestDescription_suite_Test_testTime() : CxxTest::RealTestDescription( Tests_Test, suiteDescription_Test, 22, "testTime" ) {}
 void runTest() { suite_Test.testTime(); }
} testDescription_suite_Test_testTime;

static class TestDescription_suite_Test_testTime2 : public CxxTest::RealTestDescription {
public:
 TestDescription_suite_Test_testTime2() : CxxTest::RealTestDescription( Tests_Test, suiteDescription_Test, 39, "testTime2" ) {}
 void runTest() { suite_Test.testTime2(); }
} testDescription_suite_Test_testTime2;

static class TestDescription_suite_Test_testDate : public CxxTest::RealTestDescription {
public:
 TestDescription_suite_Test_testDate() : CxxTest::RealTestDescription( Tests_Test, suiteDescription_Test, 48, "testDate" ) {}
 void runTest() { suite_Test.testDate(); }
} testDescription_suite_Test_testDate;

static class TestDescription_suite_Test_testAppointment : public CxxTest::RealTestDescription {
public:
 TestDescription_suite_Test_testAppointment() : CxxTest::RealTestDescription( Tests_Test, suiteDescription_Test, 62, "testAppointment" ) {}
 void runTest() { suite_Test.testAppointment(); }
} testDescription_suite_Test_testAppointment;

static class TestDescription_suite_Test_testAppointment2 : public CxxTest::RealTestDescription {
public:
 TestDescription_suite_Test_testAppointment2() : CxxTest::RealTestDescription( Tests_Test, suiteDescription_Test, 84, "testAppointment2" ) {}
 void runTest() { suite_Test.testAppointment2(); }
} testDescription_suite_Test_testAppointment2;

static class TestDescription_suite_Test_testMonthly : public CxxTest::RealTestDescription {
public:
 TestDescription_suite_Test_testMonthly() : CxxTest::RealTestDescription( Tests_Test, suiteDescription_Test, 112, "testMonthly" ) {}
 void runTest() { suite_Test.testMonthly(); }
} testDescription_suite_Test_testMonthly;

static class TestDescription_suite_Test_testDaily : public CxxTest::RealTestDescription {
public:
 TestDescription_suite_Test_testDaily() : CxxTest::RealTestDescription( Tests_Test, suiteDescription_Test, 157, "testDaily" ) {}
 void runTest() { suite_Test.testDaily(); }
} testDescription_suite_Test_testDaily;

static class TestDescription_suite_Test_testOnetime : public CxxTest::RealTestDescription {
public:
 TestDescription_suite_Test_testOnetime() : CxxTest::RealTestDescription( Tests_Test, suiteDescription_Test, 204, "testOnetime" ) {}
 void runTest() { suite_Test.testOnetime(); }
} testDescription_suite_Test_testOnetime;

#include <cxxtest/Root.cpp>
const char* CxxTest::RealWorldDescription::_worldName = "cxxtest";
